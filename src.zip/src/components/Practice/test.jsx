export function Test() {

  return (
    <>
      {/* <div className='bg-deepblue container'>
        <h1 className='text-5xl font-bold text-white'>Welcome with tailwind</h1>
        
        <button className='bg-amber text-alambaster border-4 text-2xl font-bold mt-12 rounded px-6 py-4 animate-pulse'>Click me!</button>

        <input type='text' placeholder='Enter your name' className='bg-white text-lg text-amber border-2 p-4 rounded-2xl ml-4 outline-0'/>
      </div> */}

      {/* <div className='@container border p-4'>
        <div className='grid grid-cols-1 @sm:grid-cols-3 @max-md:grid-cols-1 gap-4'>
          <div className='bg-blue-500 h-40'></div>
          <div className='bg-green-500 h-40'></div>
          <div className='bg-red-500 h-40'></div>
          <div className='bg-yellow-500 h-40'></div>
        </div>
      </div> */}

      {/* <div className='@container border p-4'>
        <div className='flex gap-4'>
          <div className='bg-blue-500 h-40 w-64 '></div>
          <div className='bg-green-500 h-40 w-64 @min-md:@max-xl:hidden'></div>
          <div className='bg-red-500 h-40 w-64 '></div>
          <div className='bg-yellow-500 h-40 w-64'></div>
        </div>
      </div> */}

      {/* <div className='min-h-screen flex items-center justify-center bg-gray-100 perspective-1000'>
        <div className='bg-blue-500 h-96 w-96 flex items-center justify-center text-white text-4xl font-bold transform hover:scale-120 hover:translate-z-20 translation-transform duration-300'>3D rotate
        </div>
      </div> */}


      {/* <div className='min-h-screen flex items-center justify-center bg-gray-100'>
        <div className='bg-linear-45 from-blue-500 to-green-500 p-8 rounded-3xl text-2xl font-bold text-white hover:scale-110 duration-300'>
          Angled Gradient APIs
        </div>
      </div> */}

      {/* <div className='min-h-screen flex items-center justify-center bg-gray-100'>
        <div className='size-64 rounded-full bg-conic-180 from-indigo-600 via-indigo-50 to-indigo-600'></div>
        <div className='bg-radial from-yellow-500 to-red-500 h-64 w-64 rounded-full ml-5'></div>
      </div> */}


      {/* <div className='min-h-screen grid gap-4 place-items-center bg-deepblue'>
        <input type="text" placeholder='Enter your name' className='inset-shadow-sm inset-shadow-amber-500 border-4 rounded-sm w-96 h-18 p-4 text-xl text-amber outline-none'/>

        <input type="text" placeholder='Enter your name' className='inset-shadow-sm inset-shadow-amber-500 ring-4 rounded-sm w-96 h-18 p-4 text-xl text-amber outline-none'/>
        
        <input type="text" placeholder='Enter your name' className='inset-ring-4 inset-ring-amber-500 border-4 rounded-sm w-96 h-18 p-4 text-xl text-amber outline-none'/>
        </div> */}


      {/* <div className='min-h-screen flex - items-center justify-center bg-gray-100'>
        <ul className='space-y-4 text-center'>
        <li className='bg-gray-200 p-4 rounded text-lg not-active:bg-red-500'>Item 1</li>
        <li className='bg-gray-200 p-4 rounded text-lg '>Item 2 (Active)</li>
        <li className='bg-gray-200 p-4 rounded text-lg not-active:bg-red-500'>Item 3</li>
        </ul>
      </div> */}
    </>
  )
}